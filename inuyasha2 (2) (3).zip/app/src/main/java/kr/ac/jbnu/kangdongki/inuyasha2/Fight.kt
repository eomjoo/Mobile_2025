package kr.ac.jbnu.kangdongki.inuyasha2

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Fight : AppCompatActivity() {

    private lateinit var heroImage: ImageView
    private lateinit var enemyImage: ImageView
    private var yourHealth = 100
    private var enemyHealth = 100
    private val damage = 30
    lateinit var yourHealthBar: ProgressBar
    lateinit var enemyHealthBar: ProgressBar
    private val defendDamage = 15

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fight)

        heroImage = findViewById(R.id.heroImage)
        enemyImage = findViewById(R.id.enemyImage)

        val playerChampion = intent.getIntExtra("playerChampion", -1)
        val opponentChampion = intent.getIntExtra("opponentChampion", -1)
        val heroActions = intent.getStringArrayListExtra("heroActions") ?: arrayListOf()
        val enemyActions = intent.getStringArrayListExtra("enemyActions") ?: arrayListOf()



        fun enemyTurn() {
            val enemyAction = listOf("Attack", "Defend", "Jump").random()

            when (enemyAction) {
                "Attack" -> {
                    attack(enemyImage, false)
                    yourHealth -= 30
                    if (yourHealth < 0) yourHealth = 0
                }

                "Defend" -> {
                    defend(enemyImage, false)
                    enemyHealth += 15
                    if (enemyHealth > 100) enemyHealth = 100
                }

                "Jump" -> {
                    jump(enemyImage)
                }
            }
        }
        var index = 0
        fun heroTurn(){
            val heroaction=heroActions[index]
            when(heroaction){
                "attack"-> attack(heroImage, true)
                "defend" -> defend(enemyImage, false)
                "jump" -> jump(heroImage)
            }
            index++
        }

        if (playerChampion != -1 && opponentChampion != -1) {
            heroImage.setImageResource(playerChampion)
            enemyImage.setImageResource(opponentChampion)
        }

        yourHealthBar = findViewById(kr.ac.jbnu.kangdongki.inuyasha2.R.id.yourHealthBar)
        enemyHealthBar = findViewById(kr.ac.jbnu.kangdongki.inuyasha2.R.id.enemyHealthBar)
        yourHealthBar.progress = yourHealth
        enemyHealthBar.progress = enemyHealth

        // Gọi lượt đánh
        enemyTurn()
        heroTurn()
    }

    private fun enemyTurn() {
        attack(enemyImage, false)
    }

    private fun heroTurn() {
        attack(heroImage, true)
    }

    private fun attack(attacker: ImageView, isHeroAttacking: Boolean) {
        val attackAnim = TranslateAnimation(0f, 100f, 0f, 0f).apply {
            duration = 150
            repeatCount = 1
            repeatMode = Animation.REVERSE
        }
        attacker.startAnimation(attackAnim)

        if (isHeroAttacking) {
            enemyHealth -= damage
            if (enemyHealth < 0) enemyHealth = 0
            enemyHealthBar.progress = enemyHealth

            if (enemyHealth == 0) {
                Toast.makeText(this, "Win!", Toast.LENGTH_SHORT).show()
            }
        } else {
            yourHealth -= damage
            if (yourHealth < 0) yourHealth = 0
            yourHealthBar.progress = yourHealth

            if (yourHealth == 0) {
                Toast.makeText(this, "You Lose!", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun defend(defender: ImageView, isHeroAttacking: Boolean) {
        val shake = TranslateAnimation(0f, 15f, 0f, 0f).apply {
            duration = 50
            repeatCount = 5
            repeatMode = Animation.REVERSE
        }
        defender.startAnimation(shake)

        if (isHeroAttacking) {
            enemyHealth -= defendDamage
            if (enemyHealth < 0) enemyHealth = 0
            enemyHealthBar.progress = enemyHealth

            if (enemyHealth == 0) {
                Toast.makeText(this, "Win!", Toast.LENGTH_SHORT).show()
            }
        } else {
            yourHealth -= defendDamage
            if (yourHealth < 0) yourHealth = 0
            yourHealthBar.progress = yourHealth

            if (yourHealth == 0) {
                Toast.makeText(this, "You Lose!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun jump(view: ImageView) {
        val jump = TranslateAnimation(0f, 0f, 0f, -150f).apply {
            duration = 300
            repeatCount = 1
            repeatMode = Animation.REVERSE
        }
        view.startAnimation(jump)

        yourHealth -= 0
        enemyHealth -=0

    }
}