package com.example.inuyasha

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.inuyasha.databinding.ActivityDifficultyBinding


class DifficultyActivity : BaseActivity() {
    private lateinit var binding: ActivityDifficultyBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDifficultyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //난이도 버튼 추가
        binding.normalButton.setOnClickListener {
            val intent = Intent(this, Play::class.java)
            intent.putExtra("difficulty", "normal")
            startActivity(intent)
            finish()
        }
        binding.hardButton.setOnClickListener {
            val intent = Intent(this, Play::class.java)
            intent.putExtra("difficulty", "normal")
            startActivity(intent)
            finish()
        }
    }
}