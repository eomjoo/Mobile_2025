package kr.ac.jbnu.kangdongki.inuyasha2

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class skills : AppCompatActivity() {
    private lateinit var btnContinue: Button
    private lateinit var btnChangeHero: Button
    private lateinit var resultButtonsLayout: LinearLayout
    private lateinit var charactercontrol: LinearLayout

    private lateinit var heroImage: ImageView
    private lateinit var enemyImage: ImageView

    private lateinit var btnAttack: Button
    private lateinit var btnDefend: Button
    private lateinit var btnJump: Button

    lateinit var yourHealthBar: ProgressBar
    lateinit var enemyHealthBar: ProgressBar
    var yourHealth = 100
    var enemyHealth = 100// Máu tối đa 100
    private val damage = 30
    private val defendDamage = 15


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skills)

        btnContinue = findViewById(R.id.btnContinue)
        btnChangeHero = findViewById(R.id.btnChangeHero)
        resultButtonsLayout = findViewById(R.id.resultButtonsLayout)
        charactercontrol=findViewById(R.id.charactercontrol)

        btnContinue.setOnClickListener {
            yourHealth += 100
            enemyHealth =+ 100

            yourHealthBar.progress = yourHealth
            enemyHealthBar.progress = enemyHealth

            charactercontrol.visibility=View.VISIBLE
            resultButtonsLayout.visibility = View.INVISIBLE


        }

        btnChangeHero.setOnClickListener {
            val intent = Intent(this, Play::class.java)
            startActivity(intent)
            finish()
        }

        heroImage = findViewById(R.id.heroImage)
        enemyImage = findViewById(R.id.enemyImage)

        val playerChampion = intent.getIntExtra("playerChampion", -1)
        val opponentChampion = intent.getIntExtra("opponentChampion", -1)

        if (playerChampion != -1 && opponentChampion != -1) {
            heroImage.setImageResource(playerChampion)
            enemyImage.setImageResource(opponentChampion)
        }

        yourHealthBar = findViewById(kr.ac.jbnu.kangdongki.inuyasha2.R.id.yourHealthBar)
        enemyHealthBar = findViewById(kr.ac.jbnu.kangdongki.inuyasha2.R.id.enemyHealthBar)
        yourHealthBar.progress = yourHealth
        enemyHealthBar.progress = enemyHealth

        btnAttack = findViewById(R.id.btnAttack)
        btnDefend = findViewById(R.id.btnDefend)
        btnJump = findViewById(R.id.btnJump)

        btnAttack.setOnClickListener {
            attack(heroImage)
        }

        btnDefend.setOnClickListener {
            defend(heroImage)
        }

        btnJump.setOnClickListener {
            jump(heroImage)
        }
    }

    // Hiệu ứng tấn công: dịch sang phải rồi quay lại
    private fun attack(view: ImageView) {
        val attackAnim = TranslateAnimation(0f, 100f, 0f, 0f).apply {
            duration = 150
            repeatCount = 1
            repeatMode = Animation.REVERSE
        }
        view.startAnimation(attackAnim)

        enemyHealth -= damage
        if (enemyHealth < 0) enemyHealth = 0
        enemyHealthBar.progress = enemyHealth

        // Kiểm tra nếu máu đối thủ = 0 thì thắng
        if (enemyHealth == 0) {
            Toast.makeText(this, "Win!", Toast.LENGTH_SHORT).show()
            resultButtonsLayout.visibility = View.VISIBLE
            charactercontrol.visibility=View.INVISIBLE
        }

    }

    // Hiệu ứng phòng thủ: rung nhẹ sang ngang
    private fun defend(view: ImageView) {
        val shake = TranslateAnimation(0f, 15f, 0f, 0f).apply {
            duration = 50
            repeatCount = 5
            repeatMode = Animation.REVERSE
        }
        view.startAnimation(shake)

        yourHealth -= defendDamage
        if (yourHealth < 0) yourHealth = 0
        yourHealthBar.progress = yourHealth

        // Kiểm tra nếu máu bạn về 0 thì xử lý thua
        if (yourHealth == 0) {
            Toast.makeText(this, "You Lose!", Toast.LENGTH_SHORT).show()
            resultButtonsLayout.visibility = View.VISIBLE
            charactercontrol.visibility=View.INVISIBLE
        }
    }

    // Hiệu ứng nhảy lên rồi hạ xuống
    private fun jump(view: ImageView) {
        val jump = TranslateAnimation(0f, 0f, 0f, -150f).apply {
            duration = 300
            repeatCount = 1
            repeatMode = Animation.REVERSE
        }
        view.startAnimation(jump)

        yourHealth -= 0

    }
    }
